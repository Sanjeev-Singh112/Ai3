# Cyclemon - GitHub Pages Website

A static website version of Cyclemon, optimized for GitHub Pages deployment.

## Features

- **Responsive Design**: Works on all devices
- **Smooth Scrolling**: Section-based navigation with indicators
- **Interactive Elements**: Forms, chat interface, and upload areas
- **Modern Styling**: Gradient backgrounds and glass-morphism effects
- **Accessibility**: Semantic HTML and keyboard navigation

## Deployment to GitHub Pages

1. **Create a new repository** on GitHub
2. **Upload these files** to your repository
3. **Enable GitHub Pages**:
   - Go to repository Settings
   - Scroll to "Pages" section
   - Select "Deploy from a branch"
   - Choose "main" branch and "/ (root)" folder
   - Click Save

Your website will be available at: `https://yourusername.github.io/repository-name`

## File Structure

\`\`\`
├── index.html          # Main HTML file
├── styles.css          # All CSS styles
├── script.js           # JavaScript functionality
└── README.md           # This file
\`\`\`

## Customization

### Colors
The website uses a vibrant color palette. You can modify colors in `styles.css`:
- Primary: #E85A7A (pink)
- Secondary: #F4A261 (orange)
- Background: #E8D5B7 (beige)

### Content
Edit `index.html` to modify:
- Section content
- Contact information
- Profile details
- Disclaimer text

### Functionality
Modify `script.js` to add:
- Form validation
- API integrations
- Additional interactions

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

© 2024 Cyclemon. All rights reserved.
