// Import Lucide icons library
import lucide from "lucide"

// Initialize Lucide icons
lucide.createIcons()

// Section navigation functionality
let currentSection = 0
const totalSections = 10

// Update active indicator
function updateActiveIndicator(sectionIndex) {
  const indicators = document.querySelectorAll(".indicator")
  indicators.forEach((indicator, index) => {
    if (index === sectionIndex) {
      indicator.classList.add("active")
    } else {
      indicator.classList.remove("active")
    }
  })
}

// Scroll to section
function scrollToSection(sectionIndex) {
  const section = document.getElementById(`section-${sectionIndex}`)
  if (section) {
    section.scrollIntoView({ behavior: "smooth" })
  }
}

// Handle scroll events
function handleScroll() {
  const sections = document.querySelectorAll(".scroll-section")
  const scrollPosition = window.scrollY + window.innerHeight / 2

  sections.forEach((section, index) => {
    const offsetTop = section.offsetTop
    const offsetBottom = offsetTop + section.offsetHeight

    if (scrollPosition >= offsetTop && scrollPosition < offsetBottom) {
      if (currentSection !== index) {
        currentSection = index
        updateActiveIndicator(index)
      }
    }
  })
}

// Add event listeners
document.addEventListener("DOMContentLoaded", () => {
  // Section indicators
  const indicators = document.querySelectorAll(".indicator")
  indicators.forEach((indicator, index) => {
    indicator.addEventListener("click", () => {
      scrollToSection(index)
    })
  })

  // Scroll indicator in hero section
  const scrollIndicator = document.querySelector(".scroll-indicator")
  if (scrollIndicator) {
    scrollIndicator.addEventListener("click", () => {
      scrollToSection(1)
    })
  }

  // Scroll event listener
  window.addEventListener("scroll", handleScroll)

  // Form submission (contact form)
  const contactForm = document.querySelector(".contact-form")
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault()
      alert("Thank you for your message! We will get back to you soon.")
    })
  }

  // Upload button functionality
  const uploadButton = document.querySelector(".upload-button")
  if (uploadButton) {
    uploadButton.addEventListener("click", () => {
      const input = document.createElement("input")
      input.type = "file"
      input.multiple = true
      input.accept = ".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
      input.click()
    })
  }

  // Summarizer button functionality
  const summarizerButton = document.querySelector(".summarizer-button")
  if (summarizerButton) {
    summarizerButton.addEventListener("click", () => {
      const textarea = document.querySelector(".summarizer-textarea")
      if (textarea.value.trim()) {
        alert(
          "AI Summary: This is a sample summary of your text. In a real implementation, this would be processed by AI.",
        )
      } else {
        alert("Please enter some text to summarize.")
      }
    })
  }

  // Chat functionality
  const chatSendButton = document.querySelector(".chat-send-button")
  const chatInput = document.querySelector(".chat-input")
  const chatMessages = document.querySelector(".chat-messages")

  if (chatSendButton && chatInput && chatMessages) {
    function sendMessage() {
      const message = chatInput.value.trim()
      if (message) {
        // Add user message
        const userMessage = document.createElement("div")
        userMessage.className = "message user-message"
        userMessage.innerHTML = `<p>${message}</p>`
        chatMessages.appendChild(userMessage)

        // Clear input
        chatInput.value = ""

        // Simulate AI response
        setTimeout(() => {
          const aiMessage = document.createElement("div")
          aiMessage.className = "message ai-message"
          aiMessage.innerHTML = `<p>Thank you for your question! I'm here to help you learn. This is a sample response.</p>`
          chatMessages.appendChild(aiMessage)
          chatMessages.scrollTop = chatMessages.scrollHeight
        }, 1000)

        chatMessages.scrollTop = chatMessages.scrollHeight
      }
    }

    chatSendButton.addEventListener("click", sendMessage)
    chatInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        sendMessage()
      }
    })
  }

  // Initialize icons after DOM is loaded
  setTimeout(() => {
    lucide.createIcons()
  }, 100)
})

// Smooth scrolling for older browsers
if (!CSS.supports("scroll-behavior", "smooth")) {
  const links = document.querySelectorAll('a[href^="#"]')
  links.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
        })
      }
    })
  })
}
